require('dotenv').config();
const express = require('express');
const cors = require('cors');
/* const mongoose = require('mongoose');*/
const bodyParser = require("body-parser");
const dns = require('dns');
const app = express();

const port = process.env.PORT || 3000;/* 
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const urlSchema = new mongoose.Schema({
  original_url: String,
  short_url: String
});
const urlModel = mongoose.model('urlModel', urlSchema); */

urlBasement = [
  {original_url: "https://www.google.com", short_url: 2},
  {original_url: "https://www.freecodecamp.org", short_url: 1},
  {original_url: "https://www.reddit.com", short_url: 3}
];
let requestedUrl = [];
let original_url;

app.use(bodyParser.urlencoded({extended: false}));

app.use(cors());

app.use('/public', express.static(`${process.cwd()}/public`));

app.get('/', function(req, res) {
  res.sendFile(process.cwd() + '/views/index.html');
});

app.get('/api/hello', function(req, res) {
  res.json({ greeting: 'hello API' });
});

app.post('/api/shorturl',(req, res, next) => {
  original_url = req.body.url;
    dns.lookup(original_url, (err, address, family) => {
      if(err){
        requestedUrl = { error: 'invalid url' }
      };
    });
    next();
},(req, res) => {
  
  urlFinderOriginal(original_url);
  res.json(requestedUrl);

});

app.get('/api/shorturl/:short_url', (req, res) => {
  
  short_url = req.params.short_url;
  urlFinderShort(short_url);
  res.redirect(requestedUrl.original_url);

});

const urlFinderOriginal = (url) => {
  urlBasement.forEach(element => {

    if(element.original_url === url){
      requestedUrl = {'original_url': element.original_url, 'short_url': element.short_url};
      return;
    };
  });
};
const urlFinderShort = (url) => {
  urlBasement.forEach(element => {

    if(element.short_url === parseInt(url)){
      requestedUrl = {'original_url': element.original_url, 'short_url': element.short_url};
      return;
    };
  });
};

app.listen(port, function() {
  console.log(`Listening on port ${port}`);
});
